//#-hidden-code
import UIKit
import CoreGraphics
import PlaygroundSupport

let rect = CGRect(x: 0, y: 0, width: 375, height: 667)
let view = UIView(frame: rect)
view.backgroundColor = .black
let bubbleCreator = BubbleCreator()

enum BubbleSize {
    case se
    case seven
    case sevenPlus
    
    var widthFactor: Double {
        switch self {
        case .se:
            return Double(131)
        case .seven:
            return Double(161)
        case .sevenPlus:
            return Double(178)
        default:
            return Double(131)
        }
    }
    
    var heightFactor: Double {
        switch self {
        case .se:
            return Double(10)
        case .seven:
            return Double(17)
        case .sevenPlus:
            return Double(20)
        default:
            return Double(10)
        }
    }
}

var positionY: Double = 20

extension UIView {
    func addBubble(size: BubbleSize, color1: UIColor, color2: UIColor) {
        let path = bubbleCreator.createBubblePath(widthFactor: size.widthFactor,
                                                  heightFactor: size.heightFactor)
        
        let layer = CAShapeLayer()
        layer.path = path.cgPath
        
        let width = 50 + size.widthFactor
        let height = 42 + size.heightFactor
        let gradient = CAGradientLayer()
        gradient.frame = CGRect(x: Double(20), y: positionY, width: width, height: height)
        gradient.startPoint = CGPoint(x: 0.5, y: 0)
        gradient.endPoint = CGPoint(x: 0.5, y: 1)
        gradient.colors = [color1.cgColor, color2.cgColor]
        gradient.mask = layer
        
        self.layer.addSublayer(gradient)
        positionY += height + 10
    }
}

PlaygroundPage.current.liveView = view
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)

view.addBubble(size: .se, color1: #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 1), color2: #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 0.8007544949))
view.addBubble(size: .seven, color1: #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1), color2: #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 0.8010488014))
view.addBubble(size: .sevenPlus, color1: #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1), color2: #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 0.8025693222))
