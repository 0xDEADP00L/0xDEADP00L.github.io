import UIKit

public class BubbleCreator {
    public init() { }
    
    public func createBubblePath(widthFactor: Double, heightFactor: Double) -> UIBezierPath {
        let bubbleBackground0Path = UIBezierPath()
        // Under tale x: 0 to 25
        bubbleBackground0Path.move(to: CGPoint(x: 12.81, y: 37.8+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 25, y: 42+heightFactor),
                                       controlPoint1: CGPoint(x: 16.19, y: 40.46+heightFactor),
                                       controlPoint2: CGPoint(x: 20.41, y: 42+heightFactor))
        
        // Width 25 to 203 = 178
        bubbleBackground0Path.addLine(to: CGPoint(x: 25+widthFactor, y: 42+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 45+widthFactor, y: 22+heightFactor),
                                       controlPoint1: CGPoint(x: 36.05+widthFactor, y: 42+heightFactor),
                                       controlPoint2: CGPoint(x: 45+widthFactor, y: 33.05+heightFactor))
        
        // Height 40 to 20
        bubbleBackground0Path.addLine(to: CGPoint(x: 45+widthFactor, y: 20))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 25+widthFactor, y: 0),
                                       controlPoint1: CGPoint(x: 45+widthFactor, y: 8.95),
                                       controlPoint2: CGPoint(x: 36.05+widthFactor, y: 0))
        
        // Width 203 to 25
        bubbleBackground0Path.addLine(to: CGPoint(x: 25, y: 0))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 5, y: 20),
                                       controlPoint1: CGPoint(x: 13.95, y: 0),
                                       controlPoint2: CGPoint(x: 5, y: 8.95))
        
        // Height 20 to 42
        bubbleBackground0Path.addLine(to: CGPoint(x: 5, y: 22+heightFactor))
        
        // Tail
        bubbleBackground0Path.addCurve(to: CGPoint(x: 5, y: 22.06+heightFactor),
                                       controlPoint1: CGPoint(x: 5, y: 22.02+heightFactor),
                                       controlPoint2: CGPoint(x: 5, y: 22.04+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 4.99, y: 22.05+heightFactor),
                                       controlPoint1: CGPoint(x: 4.99, y: 22.05+heightFactor),
                                       controlPoint2: CGPoint(x: 4.99, y: 22.05+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 4.62, y: 36.13+heightFactor),
                                       controlPoint1: CGPoint(x: 4.99, y: 42.05+heightFactor),
                                       controlPoint2: CGPoint(x: 5.25, y: 32.55+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 0.16, y: 41.76+heightFactor),
                                       controlPoint1: CGPoint(x: 3.98, y: 39.71+heightFactor),
                                       controlPoint2: CGPoint(x: 0.16, y: 41.76+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 0.22, y: 42.01+heightFactor),
                                       controlPoint1: CGPoint(x: -0.08, y: 41.9+heightFactor),
                                       controlPoint2: CGPoint(x: -0.05, y: 42.01+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 12.05, y: 38.55+heightFactor),
                                       controlPoint1: CGPoint(x: 0.22, y: 42.01+heightFactor),
                                       controlPoint2: CGPoint(x: 6.56, y: 42.09+heightFactor))
        bubbleBackground0Path.addCurve(to: CGPoint(x: 12.81, y: 37.86+heightFactor),
                                       controlPoint1: CGPoint(x: 12.36, y: 38.35+heightFactor),
                                       controlPoint2: CGPoint(x: 12.61, y: 38.12+heightFactor))
        bubbleBackground0Path.close()
        bubbleBackground0Path.usesEvenOddFillRule = true
        return bubbleBackground0Path
    }
}
