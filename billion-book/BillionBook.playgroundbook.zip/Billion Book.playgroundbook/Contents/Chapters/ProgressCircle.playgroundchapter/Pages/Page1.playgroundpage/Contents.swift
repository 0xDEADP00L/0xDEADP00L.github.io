//#-hidden-code
import PlaygroundSupport
import UIKit

let vc = ViewController()

PlaygroundPage.current.liveView = vc
//#-end-hidden-code
