import UIKit

protocol DownloaderDelegate {
    func didReceiveData(_ data: Data)
}

protocol Downloader {
    var delegate: DownloaderDelegate? { get set }
    
    func startDownload()
    func stopDownload()
}

class FakeDownloader: Downloader {
    private var timer: Timer!
    private lazy var fireBlock = { [unowned self] (t: Timer) in
        self.timerTick()
    }
    
    var delegate: DownloaderDelegate?
    
    init() {
        timer = nil
        timer = Timer(timeInterval: 0.2, repeats: true, block: fireBlock)
    }
    
    deinit {
        timer.invalidate()
    }
    
    private func timerTick() {
        let randomData = Data(repeating: 0, count: Int(arc4random_uniform(64)))
        self.delegate?.didReceiveData(randomData)
    }
    
    func startDownload() {
        RunLoop.current.add(timer, forMode: .defaultRunLoopMode)
    }
    
    func stopDownload() {
        timer?.invalidate()
        timer = Timer(timeInterval: 0.2, repeats: true, block: fireBlock)
    }
}

public class ViewController: UIViewController, DownloaderDelegate {
    
    let trackLayer = CAShapeLayer()
    let strokeLayer = CAShapeLayer()
    var label: UILabel!
    
    var downloader: Downloader!
    
    var wholeAmount = 1024
    var receivedAmount = 0
    
    override public func loadView() {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
        view.backgroundColor = .black
        self.view = view
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let center = view.center
        let circularPath = UIBezierPath(arcCenter: center,
                                        radius: 100,
                                        startAngle: -CGFloat.pi/2,
                                        endAngle: 3*CGFloat.pi/2,
                                        clockwise: true)
        
        trackLayer.path = circularPath.cgPath
        
        trackLayer.strokeColor = UIColor.darkGray.cgColor
        trackLayer.lineWidth = 10
        trackLayer.fillColor = UIColor.clear.cgColor
        trackLayer.lineCap = kCALineCapRound
        
        view.layer.addSublayer(trackLayer)
        
        strokeLayer.path = circularPath.cgPath
        
        strokeLayer.strokeColor = UIColor.white.cgColor
        strokeLayer.lineWidth = 10
        strokeLayer.strokeEnd = 0
        strokeLayer.fillColor = UIColor.clear.cgColor
        strokeLayer.lineCap = kCALineCapRound
        
        view.layer.addSublayer(strokeLayer)
        
        let labelFrame = CGRect(x: center.x-50, y: center.y-10.5, width: 100, height: 21)
        label = UILabel(frame: labelFrame)
        label.layer.masksToBounds = false
        label.clipsToBounds = false
        label.text = "0.0 %"
        label.textAlignment = .center
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 17.0)
        view.addSubview(label)
        
        downloader = FakeDownloader()
        downloader.delegate = self
        
        let tapRecognizer = UITapGestureRecognizer(target: self,
                                                   action: #selector(startDownloader))
        view.addGestureRecognizer(tapRecognizer)
    }
    
    @objc
    private func startDownloader() {
        downloader.stopDownload()
        receivedAmount = 0
        strokeLayer.removeAllAnimations()
        //        strokeLayer.strokeEnd = 0
        valueChanged(to: 0.0)
        downloader.startDownload()
    }
    
    private func valueChanged(to value: Double) {
        label.text = String(format: "%.1f %%", value*100)
        
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        let newValue = value
        animation.toValue = newValue
        animation.duration = 0.1
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        strokeLayer.add(animation, forKey: "strokeAnimation\(receivedAmount)")
        //        strokeLayer.strokeEnd = CGFloat(value)
    }
    
    func didReceiveData(_ data: Data) {
        receivedAmount += data.count
        if receivedAmount < wholeAmount {
            valueChanged(to: Double(receivedAmount)/Double(wholeAmount))
        } else {
            downloader.stopDownload()
            valueChanged(to: 1.0)
            label.text = "Complete"
        }
    }
}

