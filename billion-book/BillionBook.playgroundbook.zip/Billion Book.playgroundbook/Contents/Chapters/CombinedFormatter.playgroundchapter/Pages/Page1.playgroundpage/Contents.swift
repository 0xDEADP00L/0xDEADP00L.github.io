//#-hidden-code
import Foundation
import PlaygroundSupport

let vc = MyViewController()
PlaygroundPage.current.liveView = vc

//#-end-hidden-code
vc.setDates([
    Date().addingTimeInterval(-6*dayInterval),
    Date().addingTimeInterval(-5*dayInterval),
    Date().addingTimeInterval(-4*dayInterval),
    Date().addingTimeInterval(-3*dayInterval),
    Date().addingTimeInterval(-2*dayInterval),
    Date().addingTimeInterval(-dayInterval),
    Date(),
    Date().addingTimeInterval(dayInterval),
    Date().addingTimeInterval(2*dayInterval),
    Date().addingTimeInterval(3*dayInterval),
    Date().addingTimeInterval(4*dayInterval),
    Date().addingTimeInterval(5*dayInterval),
    Date().addingTimeInterval(6*dayInterval),
    ])
