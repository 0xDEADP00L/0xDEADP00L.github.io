import UIKit

public let dayInterval: TimeInterval = 24*60*60

struct Identifiers {
    static let absoluteDateCell = "absoluteDateCell"
    static let relativeDateCell = "relativeDateCell"
}

class DatesTableDataSource: NSObject, UITableViewDataSource {
    
    var reusableCellIdentifier: String!
    var formatter: DateFormatter?
    let intervalFormatter: DateComponentsFormatter = {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.day, .hour, .minute, .second]
        formatter.unitsStyle = .abbreviated
        formatter.maximumUnitCount = 4
        return formatter
    }()
    var dates: [Date] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: reusableCellIdentifier)
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: reusableCellIdentifier)
        }
        cell?.textLabel?.text = formatter?.string(from: dates[indexPath.row])
        cell?.textLabel?.font = UIFont.systemFont(ofSize: 12.0)
        let interval = dates[indexPath.row].timeIntervalSince(Date())
        cell?.detailTextLabel?.text = intervalFormatter.string(from: interval)
        cell?.detailTextLabel?.font = UIFont.systemFont(ofSize: 10.0)
        return cell!
    }
}

class CombineDateFormatter: DateFormatter {
    var otherFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = self.locale
        formatter.setLocalizedDateFormatFromTemplate("dMMM")
        return formatter
    }
    var todayFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = self.locale
        formatter.dateStyle = .short
        formatter.doesRelativeDateFormatting = true
        return formatter
    }
    
    override func string(from date: Date) -> String {
        let startOfADay = Date(timeIntervalSince1970: Double(UInt64(Date().timeIntervalSince1970) / UInt64(dayInterval) * UInt64(dayInterval)))
        let intervalPlus = date.timeIntervalSince(startOfADay)
        let intervalMinus = startOfADay.timeIntervalSince(date)
        let gap: TimeInterval = 2
        let maxPlusInterval = 2*dayInterval - gap
        let maxMinusInterval = dayInterval - gap
        if intervalPlus < maxPlusInterval &&
            intervalMinus < maxMinusInterval {
            return todayFormatter.string(from: date)
        } else {
            return otherFormatter.string(from: date)
        }
    }
}

public class MyViewController : UIViewController {
    private weak var absoluteDatesTable: UITableView!
    private weak var relativeDatesTable: UITableView!
    private weak var combinedDatesTable: UITableView!
    
    private var absoluteDataSource: DatesTableDataSource!
    private var relativeDataSource: DatesTableDataSource!
    private var combinedDataSource: DatesTableDataSource!
    
    override public func loadView() {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
        view.backgroundColor = .white
        
        let tableW = view.frame.width/3 - 8
        let tableH = view.frame.height - 60
        
        let absLabel = UILabel(frame: CGRect(x: 0, y: 4, width: tableW, height: 22))
        absLabel.text = "Absolute date"
        absLabel.textAlignment = .center
        let relLabel = UILabel(frame: CGRect(x: tableW+8, y: 4, width: tableW, height: 22))
        relLabel.text = "Relative date"
        relLabel.textAlignment = .center
        let combineLabel = UILabel(frame: CGRect(x: (tableW*2+8*2), y: 4, width: tableW, height: 22))
        combineLabel.text = "Combined date"
        combineLabel.textAlignment = .center
        view.addSubview(absLabel)
        view.addSubview(relLabel)
        view.addSubview(combineLabel)
        
        let absoluteTableView = UITableView(frame: CGRect(x: 0, y: 30, width: tableW, height: tableH), style: .plain)
        let relativeTableView = UITableView(frame: CGRect(x: tableW+8, y: 30, width: tableW, height: tableH), style: .plain)
        let combinedTableView = UITableView(frame: CGRect(x: tableW*2+8*2, y: 30, width: tableW, height: tableH), style: .plain)
        
        view.addSubview(absoluteTableView)
        view.addSubview(relativeTableView)
        view.addSubview(combinedTableView)
        
        let cnButton = UIButton(frame: CGRect(x: 0, y: tableH+30, width: tableW, height: 28))
        cnButton.setTitle("China", for: .normal)
        cnButton.setTitleColor(.white, for: .normal)
        cnButton.backgroundColor = .darkGray
        let enButton = UIButton(frame: CGRect(x: tableW+8, y: tableH+30, width: tableW, height: 28))
        enButton.setTitle("USA", for: .normal)
        enButton.setTitleColor(.white, for: .normal)
        enButton.backgroundColor = .darkGray
        let hkButton = UIButton(frame: CGRect(x: tableW*2+8*2, y: tableH+30, width: tableW, height: 28))
        hkButton.setTitle("Hong Kong", for: .normal)
        hkButton.setTitleColor(.white, for: .normal)
        hkButton.backgroundColor = .darkGray
        
        cnButton.addTarget(self, action: #selector(self.clickCN), for: .touchUpInside)
        enButton.addTarget(self, action: #selector(self.clickEN), for: .touchUpInside)
        hkButton.addTarget(self, action: #selector(self.clickHK), for: .touchUpInside)
        
        view.addSubview(cnButton)
        view.addSubview(enButton)
        view.addSubview(hkButton)
        
        self.view = view
        self.absoluteDatesTable = absoluteTableView
        self.relativeDatesTable = relativeTableView
        self.combinedDatesTable = combinedTableView
    }
    
    override public func viewDidLoad() {
        absoluteDataSource = DatesTableDataSource()
        absoluteDataSource.reusableCellIdentifier = Identifiers.absoluteDateCell
        
        relativeDataSource = DatesTableDataSource()
        relativeDataSource.reusableCellIdentifier = Identifiers.relativeDateCell
        
        combinedDataSource = DatesTableDataSource()
        combinedDataSource.reusableCellIdentifier = Identifiers.relativeDateCell
        
        setLocale(Locale.current.identifier)
        
        absoluteDatesTable.dataSource = absoluteDataSource
        relativeDatesTable.dataSource = relativeDataSource
        combinedDatesTable.dataSource = combinedDataSource
    }
    
    private func reload() {
        absoluteDatesTable.reloadData()
        relativeDatesTable.reloadData()
        combinedDatesTable.reloadData()
    }
    
    public func setDates(_ dates: [Date]) {
        absoluteDataSource.dates = dates
        relativeDataSource.dates = dates
        combinedDataSource.dates = dates
        reload()
    }
    
    @objc private func clickCN() {
        setLocale("zh_CN")
        reload()
    }
    @objc private func clickEN() {
        setLocale("en_US")
        reload()
    }
    @objc private func clickHK() {
        setLocale("zh_HK")
        reload()
    }
    
    public func setLocale(_ localeStr: String) {
        let locale = Locale(identifier: localeStr)
        
        let absDateFormat = DateFormatter()
        absDateFormat.locale = locale
        absDateFormat.setLocalizedDateFormatFromTemplate("dMMM")
        absoluteDataSource.formatter = absDateFormat
        
        let relDateFormat = DateFormatter()
        relDateFormat.locale = locale
        relDateFormat.dateStyle = .short
        relDateFormat.doesRelativeDateFormatting = true
        relativeDataSource.formatter = relDateFormat
        
        let combineDateFormat = CombineDateFormatter()
        combineDateFormat.locale = locale
        combinedDataSource.formatter = combineDateFormat
    }
}
